#!/usr/bin/env python3

import sys
import subprocess
import importlib.util
import tkinter as tk
from tkinter import messagebox

REQUIRED_MODULES = {
    "pygame": "pygame",
    "tkinter": "tkinter"
    # tkinter is standard but if you want, can check import directly
}

def check_modules():
    missing = []
    for mod, pkg in REQUIRED_MODULES.items():
        if importlib.util.find_spec(mod) is None:
            missing.append(pkg)
    return missing

def install_modules(modules):
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", *modules])
        return True
    except subprocess.CalledProcessError:
        return False

def prompt_install_missing(modules):
    root = tk.Tk()
    root.withdraw()  # hide main window
    msg = f"Module(s) aren't found: {', '.join(modules)}.\nInstall them now?"
    answer = messagebox.askyesno("Missing Modules", msg)
    root.destroy()
    return answer

missing_modules = check_modules()
if missing_modules:
    if prompt_install_missing(missing_modules):
        success = install_modules(missing_modules)
        if success:
            print("Modules installed successfully, please restart the program.")
            sys.exit(0)
        else:
            print("Failed to install modules, please install manually.")
            sys.exit(1)
    else:
        print("Modules not installed. Exiting.")
        sys.exit(1)

# Now your full original script below
import tkinter as tk
import random
import pygame
import os

# Initialize pygame mixer for music
pygame.mixer.init()

# Path to BGSong.mp3
BASE_PATH = os.path.expanduser("~/Downloads/Pingpong")
SOUND_PATH = os.path.join(BASE_PATH, "Sound")
MUSIC_FILE = os.path.join(SOUND_PATH, "BGSong.mp3")

def lerp(a, b, t):
    return a + (b - a) * t

class Particle:
    def __init__(self, canvas, x, y, scale):
        self.canvas = canvas
        self.x = x
        self.y = y
        self.size = random.randint(int(3 * scale), int(7 * scale))
        self.id = canvas.create_oval(x, y, x + self.size, y + self.size, fill="white", outline="")
        self.vx = random.uniform(-3, 3) * scale
        self.vy = random.uniform(-3, 3) * scale
        self.alpha = 1.0

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.alpha -= 0.07
        if self.alpha <= 0:
            self.canvas.delete(self.id)
            return False
        self.canvas.move(self.id, self.vx, self.vy)
        color_val = int(255 * self.alpha)
        color = f"#{color_val:02x}{color_val:02x}{color_val:02x}"
        self.canvas.itemconfig(self.id, fill=color)
        return True

class PingPongGameAI:
    def __init__(self, root, canvas, difficulty, on_exit, settings):
        self.root = root
        self.canvas = canvas
        self.running = True
        self.paused = False
        self.on_exit = on_exit
        self.settings = settings

        self.difficulty = difficulty
        if difficulty == "Easy":
            self.ai_speed = 0.05
            self.ball_speed_mult = 1.0
        elif difficulty == "Medium":
            self.ai_speed = 0.1
            self.ball_speed_mult = 1.15
        else:  # Hard
            self.ai_speed = 0.15
            self.ball_speed_mult = 1.3

        self.width = self.canvas.winfo_width() or 800
        self.height = self.canvas.winfo_height() or 400

        self.base_width = 800
        self.base_height = 400

        self.scale = min(self.width / self.base_width, self.height / self.base_height)

        self.PADDLE_WIDTH = int(10 * self.scale)
        self.PADDLE_HEIGHT = int(80 * self.scale)
        self.BALL_SIZE = int(20 * self.scale)

        self.left_paddle_y = self.height // 2 - self.PADDLE_HEIGHT // 2
        self.right_paddle_y = self.height // 2 - self.PADDLE_HEIGHT // 2
        self.ball_x = self.width // 2
        self.ball_y = self.height // 2
        self.ball_vx = 6 * random.choice([-1, 1]) * self.ball_speed_mult * self.scale
        self.ball_vy = 4 * random.choice([-1, 1]) * self.ball_speed_mult * self.scale

        self.score_left = 0
        self.score_right = 0

        self.mouse_target_y = self.left_paddle_y
        self.paddle_y = self.left_paddle_y

        self.particles = []

        # Paddles and ball white fill
        self.left_paddle = self.canvas.create_rectangle(10, self.left_paddle_y,
                                                        10 + self.PADDLE_WIDTH, self.left_paddle_y + self.PADDLE_HEIGHT,
                                                        fill="white", outline="")
        self.right_paddle = self.canvas.create_rectangle(self.width - 20, self.right_paddle_y,
                                                         self.width - 20 + self.PADDLE_WIDTH, self.right_paddle_y + self.PADDLE_HEIGHT,
                                                         fill="white", outline="")
        self.ball = self.canvas.create_oval(self.ball_x, self.ball_y,
                                            self.ball_x + self.BALL_SIZE, self.ball_y + self.BALL_SIZE,
                                            fill="white", outline="")

        self.score_text = self.canvas.create_text(self.width // 2, int(30 * self.scale), fill="white",
                                                  font=("Consolas", int(30 * self.scale), "bold"),
                                                  text=f"{self.score_left} : {self.score_right}")

        self.canvas.bind('<Motion>', self.on_mouse_move)
        self.root.bind("<Configure>", self.on_resize)

        self.pause_btn = tk.Button(self.root, text="Pause", command=self.toggle_pause,
                                   bg="black", fg="white", activebackground="#222", activeforeground="white",
                                   font=("Consolas", max(int(12 * self.scale), 8), "bold"), relief="ridge", bd=3)
        self.pause_btn.place(x=self.width - 90, y=10, width=80, height=30)

        self.exit_btn = tk.Button(self.root, text="Exit", command=self.exit_game,
                                  bg="black", fg="white", activebackground="#222", activeforeground="white",
                                  font=("Consolas", max(int(12 * self.scale), 8), "bold"), relief="ridge", bd=3)
        self.exit_btn.place(x=10, y=10, width=80, height=30)

        self.update()

    def exit_game(self):
        self.running = False
        self.canvas.delete("all")
        self.pause_btn.destroy()
        self.exit_btn.destroy()
        self.on_exit()

    def toggle_pause(self):
        self.paused = not self.paused
        self.pause_btn.config(text="Resume" if self.paused else "Pause")

    def on_mouse_move(self, event):
        target = event.y - self.PADDLE_HEIGHT / 2
        target = max(0, min(self.height - self.PADDLE_HEIGHT, target))
        self.mouse_target_y = target

    def on_resize(self, event):
        if event.widget == self.root:
            self.canvas.config(width=event.width, height=event.height)
            self.width = event.width
            self.height = event.height

            self.scale = min(self.width / self.base_width, self.height / self.base_height)

            self.PADDLE_WIDTH = int(10 * self.scale)
            self.PADDLE_HEIGHT = int(80 * self.scale)
            self.BALL_SIZE = int(20 * self.scale)

            self.paddle_y = max(0, min(self.height - self.PADDLE_HEIGHT, self.paddle_y))
            self.right_paddle_y = max(0, min(self.height - self.PADDLE_HEIGHT, self.right_paddle_y))

            self.canvas.coords(self.left_paddle, 10, self.paddle_y, 10 + self.PADDLE_WIDTH, self.paddle_y + self.PADDLE_HEIGHT)
            self.canvas.coords(self.right_paddle, self.width - 20, self.right_paddle_y,
                               self.width - 20 + self.PADDLE_WIDTH, self.right_paddle_y + self.PADDLE_HEIGHT)
            self.canvas.coords(self.ball, self.ball_x, self.ball_y, self.ball_x + self.BALL_SIZE, self.ball_y + self.BALL_SIZE)

            self.canvas.coords(self.score_text, self.width // 2, int(30 * self.scale))
            self.canvas.itemconfig(self.score_text, font=("Consolas", max(int(30 * self.scale), 10), "bold"))

            self.pause_btn.place(x=self.width - 90, y=10, width=80, height=30)
            self.pause_btn.config(font=("Consolas", max(int(12 * self.scale), 8), "bold"))
            self.exit_btn.place(x=10, y=10, width=80, height=30)
            self.exit_btn.config(font=("Consolas", max(int(12 * self.scale), 8), "bold"))

    def update(self):
        if not self.running:
            return
        if self.paused:
            self.canvas.after(50, self.update)
            return

        self.paddle_y = lerp(self.paddle_y, self.mouse_target_y, 0.2)

        self.canvas.coords(self.left_paddle, 10, self.paddle_y, 10 + self.PADDLE_WIDTH, self.paddle_y + self.PADDLE_HEIGHT)

        self.ball_x += self.ball_vx
        self.ball_y += self.ball_vy

        if self.ball_y <= 0 or self.ball_y + self.BALL_SIZE >= self.height:
            self.ball_vy *= -1

        if (self.ball_x <= 20 and
            self.paddle_y < self.ball_y + self.BALL_SIZE and
            self.ball_y < self.paddle_y + self.PADDLE_HEIGHT):
            self.ball_vx = abs(self.ball_vx) * self.ball_speed_mult
            self.ball_x = 20
            if self.settings["particles"]:
                self.spawn_particles(self.ball_x + self.BALL_SIZE // 2, self.ball_y + self.BALL_SIZE // 2)
            self.ball_vy += random.uniform(-2 * self.scale, 2 * self.scale)

        if (self.ball_x + self.BALL_SIZE >= self.width - 20 and
            self.right_paddle_y < self.ball_y + self.BALL_SIZE and
            self.ball_y < self.right_paddle_y + self.PADDLE_HEIGHT):
            self.ball_vx = -abs(self.ball_vx) * self.ball_speed_mult
            self.ball_x = self.width - 20 - self.BALL_SIZE
            if self.settings["particles"]:
                self.spawn_particles(self.ball_x + self.BALL_SIZE // 2, self.ball_y + self.BALL_SIZE // 2)
            self.ball_vy += random.uniform(-2 * self.scale, 2 * self.scale)

        if self.ball_x < 0:
            self.score_right += 1
            self.reset_ball(direction=1)
        elif self.ball_x > self.width:
            self.score_left += 1
            self.reset_ball(direction=-1)

        # AI paddle with randomness
        target_y = self.ball_y - self.PADDLE_HEIGHT / 2 + random.uniform(-30 * self.scale, 30 * self.scale)
        target_y = max(0, min(self.height - self.PADDLE_HEIGHT, target_y))
        self.right_paddle_y = lerp(self.right_paddle_y, target_y, self.ai_speed)

        self.canvas.coords(self.right_paddle, self.width - 20, self.right_paddle_y,
                           self.width - 20 + self.PADDLE_WIDTH, self.right_paddle_y + self.PADDLE_HEIGHT)

        self.canvas.coords(self.ball, self.ball_x, self.ball_y, self.ball_x + self.BALL_SIZE, self.ball_y + self.BALL_SIZE)

        self.canvas.itemconfig(self.score_text, text=f"{self.score_left} : {self.score_right}")

        if self.settings["particles"]:
            self.particles = [p for p in self.particles if p.update()]
        else:
            # clear particles if off
            for p in self.particles:
                self.canvas.delete(p.id)
            self.particles.clear()

        self.canvas.after(16, self.update)

    def reset_ball(self, direction=1):
        self.ball_x = self.width // 2
        self.ball_y = self.height // 2
        self.ball_vx = 6 * direction * self.ball_speed_mult * self.scale * random.choice([0.9, 1.0, 1.1])
        self.ball_vy = 4 * random.choice([-1, 1]) * self.ball_speed_mult * self.scale
        self.particles.clear()

    def spawn_particles(self, x, y):
        for _ in range(8):
            self.particles.append(Particle(self.canvas, x, y, self.scale))

class MainApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Ping Pong 2D")
        self.root.geometry("900x500")
        self.root.configure(bg="black")

        self.canvas = tk.Canvas(root, bg="black", highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)

        self.current_screen = None

        # Settings storage
        self.settings = {
            "music": True,
            "particles": True,
            "fullscreen": False,
        }

        self.music_playing = False

        self.show_main_menu()

    def play_music(self):
        try:
            if not pygame.mixer.music.get_busy():
                pygame.mixer.music.load(MUSIC_FILE)
                pygame.mixer.music.play(-1)
                self.music_playing = True
        except Exception as e:
            print(f"Music error: {e}")

    def stop_music(self):
        try:
            pygame.mixer.music.stop()
            self.music_playing = False
        except:
            pass

    def toggle_music(self):
        self.settings["music"] = not self.settings["music"]
        if self.settings["music"]:
            self.play_music()
        else:
            self.stop_music()
        self.show_settings()  # Refresh toggles

    def toggle_particles(self):
        self.settings["particles"] = not self.settings["particles"]
        self.show_settings()

    def toggle_fullscreen(self):
        self.settings["fullscreen"] = not self.settings["fullscreen"]
        self.root.attributes("-fullscreen", self.settings["fullscreen"])
        self.show_settings()

    def clear_screen(self):
        self.canvas.delete("all")
        for widget in self.root.winfo_children():
            if isinstance(widget, tk.Button) or isinstance(widget, tk.Label):
                widget.destroy()

    def show_main_menu(self):
        self.clear_screen()
        self.current_screen = "main_menu"

        w, h = self.root.winfo_width(), self.root.winfo_height()

        title = self.canvas.create_text(w//2, h//4, text="PING PONG 2D", fill="white",
                                        font=("Consolas", 48, "bold"))

        btn_play = tk.Button(self.root, text="Play", font=("Consolas", 20, "bold"),
                             bg="black", fg="white", relief="ridge", bd=3,
                             activebackground="#222", activeforeground="white",
                             command=self.show_difficulty_menu)
        btn_play.place(relx=0.5, rely=0.5, anchor=tk.CENTER, width=200, height=50)

        btn_settings = tk.Button(self.root, text="Settings", font=("Consolas", 20, "bold"),
                                 bg="black", fg="white", relief="ridge", bd=3,
                                 activebackground="#222", activeforeground="white",
                                 command=self.show_settings)
        btn_settings.place(relx=0.5, rely=0.6, anchor=tk.CENTER, width=200, height=50)

        btn_credits = tk.Button(self.root, text="Credits", font=("Consolas", 20, "bold"),
                                bg="black", fg="white", relief="ridge", bd=3,
                                activebackground="#222", activeforeground="white",
                                command=self.show_credits)
        btn_credits.place(relx=0.5, rely=0.7, anchor=tk.CENTER, width=200, height=50)

        # Start music if enabled and not playing
        if self.settings["music"] and not self.music_playing:
            self.play_music()

    def show_difficulty_menu(self):
        self.clear_screen()
        self.current_screen = "difficulty_menu"
        w, h = self.root.winfo_width(), self.root.winfo_height()

        title = self.canvas.create_text(w//2, h//4, text="Select Difficulty", fill="white",
                                        font=("Consolas", 36, "bold"))

        btn_easy = tk.Button(self.root, text="Easy", font=("Consolas", 20, "bold"),
                             bg="black", fg="white", relief="ridge", bd=3,
                             activebackground="#222", activeforeground="white",
                             command=lambda: self.start_game("Easy"))
        btn_easy.place(relx=0.5, rely=0.45, anchor=tk.CENTER, width=200, height=50)

        btn_medium = tk.Button(self.root, text="Medium", font=("Consolas", 20, "bold"),
                               bg="black", fg="white", relief="ridge", bd=3,
                               activebackground="#222", activeforeground="white",
                               command=lambda: self.start_game("Medium"))
        btn_medium.place(relx=0.5, rely=0.55, anchor=tk.CENTER, width=200, height=50)

        btn_hard = tk.Button(self.root, text="Hard", font=("Consolas", 20, "bold"),
                             bg="black", fg="white", relief="ridge", bd=3,
                             activebackground="#222", activeforeground="white",
                             command=lambda: self.start_game("Hard"))
        btn_hard.place(relx=0.5, rely=0.65, anchor=tk.CENTER, width=200, height=50)

        btn_back = tk.Button(self.root, text="Back", font=("Consolas", 16, "bold"),
                             bg="black", fg="white", relief="ridge", bd=3,
                             activebackground="#222", activeforeground="white",
                             command=self.show_main_menu)
        btn_back.place(x=10, y=10, width=80, height=30)

    def start_game(self, difficulty):
        self.clear_screen()
        self.current_screen = "game"
        self.game = PingPongGameAI(self.root, self.canvas, difficulty, self.show_main_menu, self.settings)

    def show_settings(self):
        self.clear_screen()
        self.current_screen = "settings"
        w, h = self.root.winfo_width(), self.root.winfo_height()

        title = self.canvas.create_text(w//2, h//6, text="Settings", fill="white",
                                        font=("Consolas", 40, "bold"))

        # Music toggle button
        btn_music = tk.Button(self.root,
                              text=f"Music: {'ON' if self.settings['music'] else 'OFF'}",
                              font=("Consolas", 20, "bold"),
                              bg="black", fg="white",
                              relief="ridge", bd=3,
                              activebackground="#222", activeforeground="white",
                              command=self.toggle_music)
        btn_music.place(relx=0.5, rely=0.4, anchor=tk.CENTER, width=250, height=50)

        # Particles toggle
        btn_particles = tk.Button(self.root,
                                  text=f"Particles: {'ON' if self.settings['particles'] else 'OFF'}",
                                  font=("Consolas", 20, "bold"),
                                  bg="black", fg="white",
                                  relief="ridge", bd=3,
                                  activebackground="#222", activeforeground="white",
                                  command=self.toggle_particles)
        btn_particles.place(relx=0.5, rely=0.5, anchor=tk.CENTER, width=250, height=50)

        # Fullscreen toggle
        btn_fullscreen = tk.Button(self.root,
                                   text=f"Fullscreen: {'ON' if self.settings['fullscreen'] else 'OFF'}",
                                   font=("Consolas", 20, "bold"),
                                   bg="black", fg="white",
                                   relief="ridge", bd=3,
                                   activebackground="#222", activeforeground="white",
                                   command=self.toggle_fullscreen)
        btn_fullscreen.place(relx=0.5, rely=0.6, anchor=tk.CENTER, width=250, height=50)

        btn_back = tk.Button(self.root, text="Back", font=("Consolas", 16, "bold"),
                             bg="black", fg="white", relief="ridge", bd=3,
                             activebackground="#222", activeforeground="white",
                             command=self.show_main_menu)
        btn_back.place(x=10, y=10, width=80, height=30)

    def show_credits(self):
        self.clear_screen()
        self.current_screen = "credits"
        w, h = self.root.winfo_width(), self.root.winfo_height()

        credit_text = (
            "PING PONG 2D\n\n"
            "Created with Python\n"
            "Music: Slow motion - Ben sound\n"
            "Some code help with chatgpt\n"
            "\nalso thanks to you for playing :D"
        )
        lbl = tk.Label(self.root, text=credit_text, font=("Consolas", 18), fg="white", bg="black", justify=tk.CENTER)
        lbl.place(relx=0.5, rely=0.4, anchor=tk.CENTER)

        btn_back = tk.Button(self.root, text="Back", font=("Consolas", 16, "bold"),
                             bg="black", fg="white", relief="ridge", bd=3,
                             activebackground="#222", activeforeground="white",
                             command=self.show_main_menu)
        btn_back.place(x=10, y=10, width=80, height=30)


if __name__ == "__main__":
    root = tk.Tk()
    app = MainApp(root)
    root.mainloop()

